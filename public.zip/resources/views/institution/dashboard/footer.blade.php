<footer class="contentF">
	<div id="footerAd" class="clearfix">
		<div class="pull-left">
		<b>Derechos Reservados </b>&copy; {{ date('Y') }}
		</div>
		<div class="pull-right">
			@tenea
		</div> 
	</div> 
</footer>